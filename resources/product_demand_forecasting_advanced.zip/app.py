import streamlit as st, pandas as pd, numpy as np, plotly.graph_objects as go
from advanced_model import prep,compare,sarimax,future_tree,plan

st.set_page_config(page_title="Advanced Demand Planning",layout="wide")
st.title("Advanced Demand Forecasting & Production Planning")
up=st.file_uploader("Upload CSV",type="csv")
if not up: st.info("Required: date, sku, sales, inventory. Optional: price, promo, marketing, market, lead_time, incoming_supply."); st.stop()
d=prep(pd.read_csv(up)); sku=st.selectbox("SKU",sorted(d.sku.unique()))
days=st.number_input("Validation holdout days",7,120,30); horizon=st.number_input("Forecast horizon",7,180,30)
service=st.select_slider("Service level",[.90,.95,.975,.99],value=.95); review=st.number_input("Review period",1,60,7)
with st.spinner("Comparing models..."): results=compare(d,days)
try: results["SARIMAX"]=sarimax(d,sku,days)
except Exception: pass
table=pd.DataFrame([{"Model":k,**v["metrics"]} for k,v in results.items()]).sort_values("RMSE")
st.subheader("Model comparison"); st.dataframe(table.style.format({"MAE":"{:.2f}","RMSE":"{:.2f}","WAPE":"{:.2%}","sMAPE":"{:.2%}"}),use_container_width=True)
choice=st.selectbox("Model used for forecast",list(table.Model))
r=results[choice]
if choice=="SARIMAX": f=pd.DataFrame({"date":r["model"].forecast(horizon).index,"forecast_demand":np.maximum(0,r["model"].forecast(horizon).values)})
else: f=future_tree(r["model"],d,sku,horizon)
v=r["validation"]; std=float(np.std(v.sales-v.prediction)); last=d[d.sku==sku].sort_values("date").iloc[-1]
p,ss,rp,prod,sd,su=plan(f,float(last.inventory),float(last.incoming_supply),int(last.lead_time),service,review,std)
a=st.columns(6); a[0].metric("Current inventory",f"{last.inventory:,.0f}"); a[1].metric("Forecast",f"{f.forecast_demand.sum():,.0f}"); a[2].metric("Safety stock",f"{ss:,.0f}"); a[3].metric("Reorder point",f"{rp:,.0f}"); a[4].metric("Recommended production",f"{prod:,.0f}"); a[5].metric("Stockout days",sd)
fig=go.Figure(); h=d[d.sku==sku].tail(180); fig.add_trace(go.Scatter(x=h.date,y=h.sales,name="Historical")); fig.add_trace(go.Scatter(x=f.date,y=f.forecast_demand,name="Forecast")); st.plotly_chart(fig,use_container_width=True)
fig2=go.Figure(); fig2.add_trace(go.Scatter(x=p.date,y=p.projected_inventory,name="Projected inventory")); fig2.add_hline(y=0,line_dash="dash",annotation_text="Stockout"); fig2.add_hline(y=ss,line_dash="dot",annotation_text="Safety stock"); fig2.add_hline(y=rp,line_dash="dot",annotation_text="Reorder point"); st.plotly_chart(fig2,use_container_width=True)
st.metric("Projected stockout units",f"{su:,.0f}")
st.dataframe(p,use_container_width=True)
st.download_button("Download planning CSV",p.to_csv(index=False).encode(),"planning_output.csv","text/csv")
st.markdown("### Methods: HistGradientBoosting + RandomForest + SARIMAX. The best model can be selected using validation RMSE. The selected forecast feeds safety stock, reorder point, stockout detection and production recommendation.")
